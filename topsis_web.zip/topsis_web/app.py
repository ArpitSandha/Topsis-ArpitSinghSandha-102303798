import smtplib
from email.message import EmailMessage
from flask import Flask, render_template, request
import pandas as pd
import numpy as np
import os
import re

app = Flask(__name__)

UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

SENDER_EMAIL = "arpitsandha03@gmail.com"
SENDER_PASSWORD = "iuugdqddnguovnzq"   # Gmail App Password (no spaces)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/submit", methods=["POST"])
def submit():
    file = request.files.get("file")
    weights = request.form.get("weights")
    impacts = request.form.get("impacts")
    email = request.form.get("email")

    # -------- Validations --------
    if not file or not weights or not impacts or not email:
        return "Error: All fields are required"

    if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
        return "Error: Invalid email format"

    weight_list = weights.split(",")
    impact_list = impacts.split(",")

    if len(weight_list) != len(impact_list):
        return "Error: Number of weights must equal number of impacts"

    for i in impact_list:
        if i not in ["+", "-"]:
            return "Error: Impacts must be + or -"

    try:
        weight_list = list(map(float, weight_list))
    except:
        return "Error: Weights must be numeric"

    # -------- Save & Read File --------
    filepath = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(filepath)

    try:
        df = pd.read_csv(filepath)
    except:
        return "Error: Invalid CSV file"

    if df.shape[1] < 3:
        return "Error: Input file must contain at least 3 columns"

    try:
        data = df.iloc[:, 1:].astype(float)
    except:
        return "Error: Criteria columns must be numeric"

    if len(weight_list) != data.shape[1]:
        return f"Error: Number of weights ({len(weight_list)}) must match number of criteria ({data.shape[1]})"

    # -------- TOPSIS CALCULATION --------
    norm_data = data / np.sqrt((data ** 2).sum())
    weighted_data = norm_data * weight_list

    ideal_best = []
    ideal_worst = []

    for i in range(len(weight_list)):
        if impact_list[i] == "+":
            ideal_best.append(weighted_data.iloc[:, i].max())
            ideal_worst.append(weighted_data.iloc[:, i].min())
        else:
            ideal_best.append(weighted_data.iloc[:, i].min())
            ideal_worst.append(weighted_data.iloc[:, i].max())

    ideal_best = np.array(ideal_best)
    ideal_worst = np.array(ideal_worst)

    dist_best = np.sqrt(((weighted_data - ideal_best) ** 2).sum(axis=1))
    dist_worst = np.sqrt(((weighted_data - ideal_worst) ** 2).sum(axis=1))

    score = dist_worst / (dist_best + dist_worst)

    df["Topsis Score"] = score
    df["Rank"] = df["Topsis Score"].rank(ascending=False).astype(int)

    output_file = os.path.join(UPLOAD_FOLDER, "result.csv")
    df.to_csv(output_file, index=False)

    # -------- SEND EMAIL --------
    msg = EmailMessage()
    msg["Subject"] = "TOPSIS Result"
    msg["From"] = SENDER_EMAIL
    msg["To"] = email
    msg.set_content("Please find attached the TOPSIS result file.")

    with open(output_file, "rb") as f:
        msg.add_attachment(
            f.read(),
            maintype="application",
            subtype="octet-stream",
            filename="result.csv"
        )

    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
        server.login(SENDER_EMAIL, SENDER_PASSWORD)
        server.send_message(msg)

    return "TOPSIS completed successfully. Result emailed."


if __name__ == "__main__":
    app.run(debug=True)
